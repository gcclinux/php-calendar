<?php
header('Location: '.'../');
?>
