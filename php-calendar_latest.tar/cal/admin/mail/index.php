<?php
header('Location: '.'../../');
?>
