<?php
return array (
  'dbtype' => '',
  'dbhost' => '',
  'dbport' => '',
  'dbname' => '',
  'dbuser' => '',
  'dbpass' => '',
  'login' => '',
  'tcalendar' => 'key_calendar',
  'tattach' => 'key_cal_attach',
  'ucalendar' => 'http://localhost/cal/',
  'mailu' => '',
  'mailp' => '',
  'smtp' => '',
  'mport' => '',
  'mailr' => '',
  'mails' => '',
  'location' => 'Broxburn',
  'openweather' => '0c395c05e9910283f21954ad99657483',
  'geolocation' => '7733a990-ebd4-11ea-b9a6-2955706ddbf3',
  'setup' => '',
)
?>
